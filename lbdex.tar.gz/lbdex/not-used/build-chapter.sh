#!/usr/bin/env bash

LLVM_DIR=~/llvm
LLVM_RELEASE_DIR=${LLVM_DIR}/release
LLVM_TEST_DIR=${LLVM_DIR}/test
LLVM_BUILD_DIR=${LLVM_DIR}/test/build

argNum=$#
arg1=$1

In_Chapters()
{
  allch="2 3_1 3_2 3_3 3_4 3_5 4_1 4_2 5_1 6_1 7_1 8_1 8_2 9_1 9_2 9_3 \
        10_1 11_1 11_2 12_1"
  # All other Chapters
  for ch in $allch
  do
    if [ "$arg1" == "$ch" ]; then
      return 0;
    fi
  done
  return 1;
}

Has_Asm()
{
  asmch="11_1 11_2 12_1"
  # Input file include Cpu0 assembly language
  for ch in $asmch
  do
    if [ "$arg1" == "$ch" ]; then
      return 0;
    fi
  done
  return 1;
}

if test -d ${LLVM_TEST_DIR}; then
  rm -rf ${LLVM_TEST_DIR}/llvm/lib/Target/Cpu0/*
  
  In_Chapters;
  if [ "$?" != "0" ]; then
    echo "if 1"
    exit 1;
  fi

  echo "replace with Chapter$arg1"
  cp -rf chapters/"Chapter$arg1"/* ${LLVM_TEST_DIR}/llvm/lib/Target/Cpu0/.
  pushd ${LLVM_BUILD_DIR}
  rm -rf ${LLVM_BUILD_DIR}/lib/Target/Cpu0/*

  Has_Asm;
  if [ "$?" != "0" ]; then
    echo "No asm"
    cmake -DCMAKE_BUILD_TYPE=Debug -DLLVM_TARGETS_TO_BUILD=Cpu0 -G "Unix Makefiles" ../llvm
  else
    echo "Has asm"
    cmake -DCMAKE_BUILD_TYPE=Debug -DLLVM_ENABLE_PROJECTS="clang" -DLLVM_TARGETS_TO_BUILD=Cpu0 -G "Unix Makefiles" ../llvm
  fi

  make -j4
  popd
else
  echo "${LLVM_TEST_DIR} not existed"
  exit 1
fi

