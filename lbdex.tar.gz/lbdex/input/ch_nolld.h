
/// start

#include "debug.h"
#include "boot.cpp"

#include "print.h"

int test_nolld();
