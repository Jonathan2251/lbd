// clang -target mips-unknown-linux-gnu -c 1.cpp -emit-llvm -o 1.bc
// ~/llvm/test/cmake_debug_build/Debug/bin/llc -march=cpu0 -relocation-model=pic -filetype=asm 1.bc -o -

/// start
int* test_1() {
  // CHECK: call i8* @llvm.stacksave()
  static int s1[8] = {1,2,3,4,5,6,7,8};;
  
  return s1;
  // CHECK: call void @llvm.stackrestore(i8*
}
